// Initialize Firebase
  export const DB_CONFIG = {
    apiKey: "AIzaSyCQ5gDCFvBt26YflWj29suifbjc92kqsko",
    authDomain: "my-react-db-b8aad.firebaseapp.com",
    databaseURL: "https://my-react-db-b8aad.firebaseio.com",
    projectId: "my-react-db-b8aad",
    storageBucket: "my-react-db-b8aad.appspot.com",
    messagingSenderId: "697527339377"
  };

